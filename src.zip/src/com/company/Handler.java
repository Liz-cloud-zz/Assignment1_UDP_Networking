package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Handler implements Runnable{
    private Socket client;
    private BufferedReader input_message;
    private PrintWriter output_message;

    public Handler(Socket client) throws IOException {
        this.client=client;
        input_message=new BufferedReader(new InputStreamReader(client.getInputStream()));
        output_message=new PrintWriter(client.getOutputStream());

    }
    @Override
    public void run() {
        try{
            while (true){
                String request=input_message.readLine();
                if(request.contains("h")){
                    output_message.println("hey");
                }else {
                    output_message.println("Type a letter to get greating message");
                }
            }
        }finally {
            output_message.close();
            input_message.close();
        }
    }
}
