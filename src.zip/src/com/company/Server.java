package com.company;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
    private static final int PORT=8080;
    public static void main(String[] args)throws IOException {
        ServerSocket client_lister =new ServerSocket(PORT);
        System.out.println("Waiting for connection");
        Socket client= client_lister.accept();
        System.out.println("Server connected!");
        PrintWriter output=new PrintWriter(client.getOutputStream(),true);
        BufferedReader in =new BufferedReader(new InputStreamReader(client.getInputStream()));


//    }{output.println("Hey");
//        System.out.println("Closing connection");
//        client.close();
//        client.close();


    }
}
